<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>

    <link rel="stylesheet" href="style.css">

    <!-- Font-Family Add -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caprasimo&family=Catamaran:wght@700&family=Cormorant+Garamond:wght@300;400;500;600;700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;1,100;1,200;1,300;1,400;1,900&family=Roboto:wght@300;400;500;700;900&family=Rubik:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>
<body>

    <div class="continer">
        <form action="login.php" method="post">

            <div class="main-form animation">

                <div class="first-form">
                    <h2 class="login">Admin Panel</h2>

                    <?php if(isset($_GET['error'])) { ?>
                        <p class = "error"><?php echo $_GET['error']; ?></p>
                    <?php } ?>
                    <label>User Name</label>
                    <input type="text" name="uname" placeholder="User Name">
                    <br><br>
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Password">
                    <br><br>
                    <button type="submit">Login</button>
                </div>

                <div class="second-image-form">
                        
                </div>
                

                
            </div>
            
        </form>
    </div>
    
</body>
</html>